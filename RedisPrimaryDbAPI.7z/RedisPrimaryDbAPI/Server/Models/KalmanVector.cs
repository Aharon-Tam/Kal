﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace KalmanRedisPrimaryDbAPI.Models
{
  public class KalmanVector
  {
    [Key]
    public string Tenor { get; set; } = String.Empty;
    public double A1 { get; set; }
    [Required]
    public double A2 { get; set; }
    [Required]
    public double K { get; set; }

    [Required]
    [DefaultValue("kalman")]
    public string Id { get; set; } = "kalman";

    //[Required]
    //public string Id { get; set; } = $"kalman:{Guid.NewGuid().ToString()}";
  }
}
