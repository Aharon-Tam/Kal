﻿Server:
https://github.com/binarythistle/Redis-as-a-Primary-Db-with-example-in-.NET6

https://www.youtube.com/watch?v=GgyizgXwXAg&list=PLpSmZmoBaROZNRmR3BHPHY6cqNOLqLkKA&index=8

client:
https://www.c-sharpcorner.com/article/how-to-receive-real-time-data-in-net-6-client-application-using-signalr/

https://github.com/SatyaKarki/SampleSignalRClientApp

notifications
https://github.com/hey-red/SignalRNotificationExample