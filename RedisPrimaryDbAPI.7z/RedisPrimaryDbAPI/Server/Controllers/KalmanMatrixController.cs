﻿using KalmanRedisPrimaryDbAPI.Data;
using KalmanRedisPrimaryDbAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace KalmanRedisPrimaryDbAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class KalmanMatrixController : ControllerBase
  {
    private readonly IKalmanMatrixRepository _kalmanMatrixRepository;

    public KalmanMatrixController(IKalmanMatrixRepository kalmanMatrixRepository)
    {
      _kalmanMatrixRepository = kalmanMatrixRepository;
    }

    [HttpGet("{tenor}", Name= "GetKalmanVectorByTenor")]
    public ActionResult<KalmanVector> GetKalmanVectorByTenor(string tenor)
    {
      var kalmanVector = _kalmanMatrixRepository.GetKalmanVectorByTenor(tenor);
      if (kalmanVector != null)
      {
        return Ok(kalmanVector);
      }

      return NotFound();
    }

    [HttpPost]
    [Route("Vector")]
    public ActionResult<KalmanVector> CreateOrUpdateKalmanVector(KalmanVector kalmanVector)
    {
      _kalmanMatrixRepository.CreateOrUpdateKalmanVector(kalmanVector);

      return CreatedAtRoute(nameof(GetKalmanVectorByTenor), new { Tenor = kalmanVector.Tenor }, kalmanVector);
    }


    [HttpPost]
    [Route("Vectors")]
    public ActionResult<KalmanVector[]> CreateOrUpdateKalmanVectors(KalmanVector[] kalmanVectors)
    {
      var kalmanResults = new List<CreatedAtRouteResult>();

      foreach (var kalmanVector in kalmanVectors)
      {
        _kalmanMatrixRepository.CreateOrUpdateKalmanVector(kalmanVector);
        var createdAtRouteResult = CreatedAtRoute(nameof(GetKalmanVectorByTenor), new { Tenor = kalmanVector.Tenor }, kalmanVector);
        kalmanResults.Add(createdAtRouteResult);
      }

      return Ok(kalmanResults.ToArray());
    }

    [HttpGet]
    public ActionResult<IEnumerable<KalmanVector>> GetKalmanMatrix()
    {
      return Ok(_kalmanMatrixRepository.GetKalmanMatrix());
    }

    [HttpDelete]
    public ActionResult<bool> DeleteKalmanMatrix()
    {
      return Ok(_kalmanMatrixRepository.DeleteEntireKalmanMatrix());

    }
  }
}
