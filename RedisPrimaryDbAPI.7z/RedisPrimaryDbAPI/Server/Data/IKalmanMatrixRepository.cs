﻿using KalmanRedisPrimaryDbAPI.Models;

namespace KalmanRedisPrimaryDbAPI.Data;

public interface IKalmanMatrixRepository
{
  void CreateOrUpdateKalmanVector(KalmanVector kalmanVector);
  KalmanVector? GetKalmanVectorByTenor(string tenor);
  IEnumerable<KalmanVector?>? GetKalmanMatrix();
  bool DeleteEntireKalmanMatrix();
}