﻿using KalmanRedisPrimaryDbAPI.Models;
using StackExchange.Redis;

namespace KalmanRedisPrimaryDbAPI.Data
{
  public class RedisKalmanMatrixRepository : IKalmanMatrixRepository
  {
    private readonly IConnectionMultiplexer _redisMultiplexer;

    public RedisKalmanMatrixRepository(IConnectionMultiplexer redisConnectionMultiplexer)
    {
      _redisMultiplexer = redisConnectionMultiplexer;
    }

    public void CreateOrUpdateKalmanVector(KalmanVector kalmanVector)
    {
      if (kalmanVector == null)
      {
        throw new ArgumentNullException(nameof(kalmanVector));
      }

      var db = _redisMultiplexer.GetDatabase();

      var tenor = kalmanVector.Tenor;

      var kalmanRedisValue = db.StringGet(tenor);

      if (!string.IsNullOrEmpty(kalmanRedisValue))
      {
        DeleteCacheByKeyOfTenor(tenor);
      }

      var serialKalmanVector = System.Text.Json.JsonSerializer.Serialize(kalmanVector);

      var success = db.StringSet(kalmanVector.Tenor, serialKalmanVector);
      if (!success)
      {
        // log it
      }
    }

    public KalmanVector? GetKalmanVectorByTenor(string tenor)
    {
      var db = _redisMultiplexer.GetDatabase();

      var kalmanVectorEx = db.StringGet(tenor);

      if (!string.IsNullOrEmpty(kalmanVectorEx))
      {
        return System.Text.Json.JsonSerializer.Deserialize<KalmanVector>(kalmanVectorEx);
      }

      return null;
    }

    public IEnumerable<KalmanVector?>? GetKalmanMatrix()
    {
      // https://stackoverflow.com/questions/37436429/get-all-keys-from-redis-cache-database

      // https://social.msdn.microsoft.com/Forums/en-US/5226561d-094e-4b26-97c3-b8f8b505cf61/how-to-get-all-keysdata-from-redis-cache?forum=aspdotnetazure

      var kalmanVectors = new List<KalmanVector?>();

      var endPoint = _redisMultiplexer.GetEndPoints().First();
      RedisKey[] keys = _redisMultiplexer.GetServer(endPoint).Keys(pattern: "*").ToArray();
      var server = _redisMultiplexer.GetServer(endPoint);
      foreach (var key in server.Keys())
      {
        var kalmanVector = GetKalmanVectorByTenor(key);
        if (kalmanVector != null && !kalmanVector.Id.StartsWith("kalman")) continue;
        kalmanVectors.Add(kalmanVector);
      }

      return kalmanVectors;
    }

    public bool DeleteEntireKalmanMatrix()
    {
      var endPoint = _redisMultiplexer.GetEndPoints().First();
      RedisKey[] keys = _redisMultiplexer.GetServer(endPoint).Keys(pattern: "*").ToArray();
      var server = _redisMultiplexer.GetServer(endPoint);

      var success = true;

      var keyExists = true;
      while (keyExists)
      {
        keyExists = false;
        var allKeys = server.Keys();
        foreach (var key in allKeys)
        {
          var kalmanVector = GetKalmanVectorByTenor(key);
          if (kalmanVector == null) continue;
          if (!kalmanVector.Id.StartsWith("kalman")) continue;

          success = DeleteCacheByKeyOfTenor(kalmanVector);
          if (success)
            keyExists = true;

          break;
        }
      }

      return success;
    }

    public bool DeleteCacheByKeyOfTenor(KalmanVector kalmanVector)
    {
      return DeleteCacheByKeyOfTenor(kalmanVector.Tenor);
    }

    public bool DeleteCacheByKeyOfTenor(string tenor)
    {
      var db = _redisMultiplexer.GetDatabase();

      var endPoint = _redisMultiplexer.GetEndPoints().First();
      RedisKey[] keys = _redisMultiplexer.GetServer(endPoint).Keys(pattern: "*").ToArray();

      var server = _redisMultiplexer.GetServer(endPoint);
      var success =  ScanAndApplyFuncKey(tenor, server, (key) => db.KeyDelete(key));

      return success;
    }

    private bool ScanAndApplyFuncKey(string tenor, IServer server, Func<RedisKey,bool> dbFunc)
    {
      var success = true;

      var keyExists = true;
      while (keyExists)
      {
        keyExists = false;
        var allKeys = server.Keys();
        foreach (var key in allKeys)
        {
          var kalmanVector = GetKalmanVectorByTenor(key);
          if (kalmanVector == null) continue;
          if (!kalmanVector.Id.StartsWith("kalman") || kalmanVector.Tenor.Equals(tenor)) continue;
          success = dbFunc(key);
          if (success)
            keyExists = true;
          break;
        }
      }

      return success;
    }
  }
}
